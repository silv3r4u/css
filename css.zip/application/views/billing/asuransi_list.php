<?php
foreach ($list_data as $key => $data) { 
    echo $data->asuransi.' '.$data->polis_no.'<br/>';
}
die;
?>