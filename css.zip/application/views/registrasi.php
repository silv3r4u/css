<div class="kegiatan">
    
    <h1 class="informasi">Halaman Utama</h1>
    <?= img(array('src'=>'assets/images/logo-transparan.png', 'align'=>'center')) ?>
</div>