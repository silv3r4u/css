<div class="data-input" style="display: inline-block">
    <label>Nomor PMR:</label><span class="label" id="norm"></span>
    <label>Nama Pasien:</label><span class="label" id="nama"></span>
    <label>Tempat tanggal lahir:</label><span class="label" id="ttl"></span>
    <label>Alamat:</label><span class="label" id="alamat"></span>
    <label>Usia:</label><span class="label" id="umur"></span>
    <label>No. Telepon:</label><span class="label" id="telp"></span>
    <label>Pekerjaan / Aktivitas:</label><span class="label" id="pekerjaan">-</span>
</div>