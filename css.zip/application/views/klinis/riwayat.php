<div class="data-input" style="display: inline-block">
    <table width="100%">
    <tr valign="top"><td width="50%">
        <label>Riwayat Penyakit Dahulu:</label><?= form_textarea('rpd') ?>
        <label>Riwayat Penyakit Keluarga:</label><?= form_textarea('rpk') ?>
        <label>Pengobatan Sekarang:</label><?= form_textarea('ps') ?>
        <label>Obat Herbal:</label><?= form_textarea('oh') ?>
        <label>Alergi Obat:</label><?= form_textarea('ao') ?>
        <label>Alergi Lain:</label><?= form_textarea('al') ?>
        <label>Dokter Langganan</label><?= form_textarea('dl') ?>
        <label>Merokok:</label><?= form_textarea('mk') ?>
        <label>Konsumsi Alkohol:</label><?= form_textarea('ka') ?>
    </td>
    <td id="last_penyakit" width="50%">
        
    </td>
    </tr>
    </table>
</div>
<!--<span class="label"><sup>o</sup>C</span>-->