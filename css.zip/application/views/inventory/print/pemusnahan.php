<?php
require_once 'app/lib/common/master-data.php';
require_once 'app/lib/common/functions.php';

header_excel("pemusnahan-".date("d-m-Y").".xls");
?>
ARVIN NIZAR
<?php
die;
?>