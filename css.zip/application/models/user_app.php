<?php

class User_app extends CI_Model {
    
    
    
}
?>
